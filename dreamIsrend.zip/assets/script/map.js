cc.Class({
    extends: cc.Component,

    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
        floorSpriteFrames:[cc.SpriteFrame],
    },

    // use this for initialization
    onLoad: function () {
        //地图位置
        this.positions = [];
        let pos = []
        for (var i = 0; i < 5; i++)
            for (var j = 0; j < 5; j++) {
                pos[5 * i + j] = cc.p(-208 + j * 104, -238 + i * 104);
            }
        var indexs = [10, 9, 8, 23, 22, 11, 0, 7, 6, 21, 12, 1, 24, 5, 20, 13, 2, 3, 4, 19, 14, 15, 16, 17, 18];
        for (var i = 0; i < 25; i++) {
            this.positions[indexs[i]] = pos[i];
        }
        for (var index = 0; index < 25; index++) {
            var node = new cc.Node("floor");
            var sprite = node.addComponent(cc.Sprite);
            sprite.spriteFrame = this.floorSpriteFrames[0];
            node.position = this.positions[index];
            node.parent = this.node;
            if (index != 24) {
                var nodeFoolr = new cc.Node("floor");
                var sprite2 = nodeFoolr.addComponent(cc.Sprite);
                if (index == 0) {
                    sprite2.spriteFrame = this.floorSpriteFrames[4];
                } else if (index == 20) {
                    sprite2.spriteFrame = this.floorSpriteFrames[3];
                } else if (index == 7) {
                    sprite2.spriteFrame = this.floorSpriteFrames[6];
                } else if (index == 8) {
                    sprite2.spriteFrame = this.floorSpriteFrames[5];
                } 
                else if(index>8){
                    sprite2.spriteFrame = this.floorSpriteFrames[1];
                }
                else {
                    sprite2.spriteFrame = this.floorSpriteFrames[2];
                }
                nodeFoolr.position = this.positions[index];
                nodeFoolr.parent = this.node;
            }
        }

    },
    createItem(){

    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});